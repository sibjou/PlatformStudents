class HashUslData {
  final String startTaskId;
  final String seed;

  HashUslData({
    required this.startTaskId,
    required this.seed,
  });
}