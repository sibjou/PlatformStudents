import 'package:shared_preferences/shared_preferences.dart';

class TestProgressService {
  static const _taskIdKey = 'student_current_task_id';
  static const _seedKey = 'student_seed';

  static Future<void> saveProgress({
    required String taskId,
    required String seed,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_taskIdKey, taskId);
    await prefs.setString(_seedKey, seed);
  }

  static Future<Map<String, String>?> loadProgress() async {
    final prefs = await SharedPreferences.getInstance();

    final taskId = prefs.getString(_taskIdKey);
    final seed = prefs.getString(_seedKey);

    if (taskId == null || seed == null) {
      return null;
    }

    return {
      'taskId': taskId,
      'seed': seed,
    };
  }

  static Future<void> clearProgress() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_taskIdKey);
    await prefs.remove(_seedKey);
  }
}