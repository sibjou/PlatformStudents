class TaskResult {
  final String taskId;
  final String userAnswer;
  final bool isCorrect;

  TaskResult({
    required this.taskId,
    required this.userAnswer,
    required this.isCorrect,
  });
}