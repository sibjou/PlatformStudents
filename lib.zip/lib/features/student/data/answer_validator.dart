import 'task_model.dart';

class AnswerValidator {
  static bool validate({
    required Task task,
    required String userAnswer,
  }) {
    final answer = userAnswer.trim();

    if (task.type == 'u' || task.type == 'p' || task.type == 't') {
      return answer.toLowerCase() == task.answer.trim().toLowerCase();
    }

    if (task.type == 'r') {
      final userValue = double.tryParse(answer);
      final correctValue = double.tryParse(task.answer);

      if (userValue == null || correctValue == null) {
        return false;
      }

      return (userValue - correctValue).abs() <= 0.01;
    }

    return false;
  }
}