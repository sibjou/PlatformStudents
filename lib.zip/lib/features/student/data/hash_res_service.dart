import 'task_result.dart';

class HashResService {
  static String generate({
    required String seed,
    required List<TaskResult> results,
  }) {
    final parts = results
        .map((item) => '${item.taskId}:${item.userAnswer}:${item.isCorrect ? 1 : 0}')
        .join('|');

    return '$seed#$parts';
  }
}