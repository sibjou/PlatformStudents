class Task {
  final String id;
  final String type; // r, u, p, t
  final String usl;
  final String? image;
  final String answer;
  final String? idTrue;
  final String? idFalse;

  Task({
    required this.id,
    required this.type,
    required this.usl,
    this.image,
    required this.answer,
    this.idTrue,
    this.idFalse,
  });
}