import 'hash_usl_data.dart';

class HashService {
  static HashUslData? decodeHashUsl(String value) {
    final parts = value.split('-');

    if (parts.length != 2) {
      return null;
    }

    final startTaskId = parts[0].trim();
    final seed = parts[1].trim();

    if (startTaskId.isEmpty || seed.isEmpty) {
      return null;
    }

    return HashUslData(
      startTaskId: startTaskId,
      seed: seed,
    );
  }
}