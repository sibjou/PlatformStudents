import 'task_model.dart';

class TaskRepository {
  static final Map<String, Task> _tasks = {
    '1': Task(
      id: '1',
      type: 'u',
      usl: 'Сколько будет 2 + 2?',
      answer: '4',
      idTrue: '2',
      idFalse: '3',
      image: null,
    ),
    '2': Task(
      id: '2',
      type: 'r',
      usl: 'Посмотрите на картинку. Сколько будет 10 / 2?',
      answer: '5',
      idTrue: null,
      idFalse: null,
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Number_5_in_circle.svg/512px-Number_5_in_circle.svg.png',
    ),
    '3': Task(
      id: '3',
      type: 'u',
      usl: 'Сколько будет 1 + 1?',
      answer: '2',
      idTrue: null,
      idFalse: null,
      image: null,
    ),
  };

  Task? getTaskById(String id) {
    return _tasks[id];
  }
}