import 'package:flutter/material.dart';
import '../../core/app_routes.dart';
import '../data/test_progress_service.dart';

class StudentMainScreen extends StatefulWidget {
  const StudentMainScreen({super.key});

  @override
  State<StudentMainScreen> createState() => _StudentMainScreenState();
}

class _StudentMainScreenState extends State<StudentMainScreen> {
  Map<String, String>? _savedProgress;

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final progress = await TestProgressService.loadProgress();
    if (!mounted) return;

    setState(() {
      _savedProgress = progress;
    });
  }

  void _openNewTest() {
    Navigator.pushNamed(context, AppRoutes.studentSolve).then((_) {
      _loadProgress();
    });
  }

  void _continueTest() {
    if (_savedProgress == null) return;

    Navigator.pushNamed(
      context,
      AppRoutes.studentTask,
      arguments: {
        'startTaskId': _savedProgress!['taskId'],
        'seed': _savedProgress!['seed'],
      },
    ).then((_) {
      _loadProgress();
    });
  }

  @override
  Widget build(BuildContext context) {
    final hasProgress = _savedProgress != null;

    return Scaffold(
      appBar: AppBar(title: const Text('🎓 Ученик')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 500),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Добро пожаловать!\nГотовы начать тест?',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: _openNewTest,
                  child: const Text('Решить'),
                ),
                const SizedBox(height: 12),
               if (hasProgress)
                  ElevatedButton(
                    onPressed: _continueTest,
                    child: const Text('Продолжить тест'),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}