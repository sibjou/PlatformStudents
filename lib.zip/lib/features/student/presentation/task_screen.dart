import 'package:flutter/material.dart';
import '../data/answer_validator.dart';
import '../data/task_model.dart';
import '../data/task_repository.dart';
import '../data/task_result.dart';
import '../../core/app_routes.dart';
import '../data/hash_res_service.dart';
import '../data/test_progress_service.dart';

class TaskScreen extends StatefulWidget {
  const TaskScreen({super.key});

  @override
  State<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends State<TaskScreen> {
  final TextEditingController _answerController = TextEditingController();
  final List<TaskResult> _results = [];
  final TaskRepository _repository = TaskRepository();

  String _seed = '';
  Task? _currentTask;
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (_initialized) return;
    _initialized = true;

    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

    if (args != null) {
      final startTaskId = args['startTaskId']?.toString() ?? '';
      _seed = args['seed']?.toString() ?? '';
      _currentTask = _repository.getTaskById(startTaskId);
      if (_currentTask != null) {
      TestProgressService.saveProgress(
        taskId: _currentTask!.id,
        seed: _seed,
  );
}
    }
  }

  Future<void> _submitAnswer() async {
    if (_currentTask == null) return;

    final userAnswer = _answerController.text.trim();

    if (userAnswer.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Введите ответ')),
      );
      return;
    }

    final isCorrect = AnswerValidator.validate(
      task: _currentTask!,
      userAnswer: userAnswer,
    );

    final result = TaskResult(
      taskId: _currentTask!.id,
      userAnswer: userAnswer,
      isCorrect: isCorrect,
    );

    setState(() {
      _results.add(result);
    });

    final nextTaskId = isCorrect ? _currentTask!.idTrue : _currentTask!.idFalse;
    
    if (nextTaskId == null) {
      final hashRes = HashResService.generate(
        seed: _seed,
        results: _results,
      );

      _answerController.clear();

      Navigator.pushReplacementNamed(
        context,
        AppRoutes.studentResult,
        arguments: {
          'hashRes': hashRes,
        },
      );
      await TestProgressService.clearProgress();
      return;
    }

    final nextTask = _repository.getTaskById(nextTaskId);

    setState(() {
      _currentTask = nextTask;
    });

      if (_currentTask != null) {
    TestProgressService.saveProgress(
      taskId: _currentTask!.id,
      seed: _seed,
    );
    }

    _answerController.clear();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(isCorrect ? 'Верно' : 'Неверно'),
      ),
    );
  }

  @override
  void dispose() {
    _answerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final task = _currentTask;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Задача'),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 700),
            child: Padding(
              padding: const EdgeInsets.all(16),
                child: task == null
                ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Тест завершён',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text('seed: $_seed'),
                  const SizedBox(height: 16),
                  const Text(
                    'Результаты:',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: _results.isEmpty
                        ? const Center(child: Text('Нет результатов'))
                        : ListView.builder(
                            itemCount: _results.length,
                            itemBuilder: (context, index) {
                              final item = _results[index];
                              return Card(
                                child: ListTile(
                                  title: Text('Task ID: ${item.taskId}'),
                                  subtitle: Text('Ответ: ${item.userAnswer}'),
                                  trailing: Text(
                                    item.isCorrect ? 'Верно' : 'Неверно',
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Task ID: ${task.id}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text('seed: $_seed'),
                  const SizedBox(height: 16),
                  Text(
                    task.usl,
                    style: const TextStyle(fontSize: 18),
                  ),
                  const SizedBox(height: 16),
                  if (task.image != null && task.image!.isNotEmpty)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        task.image!,
                        height: 180,
                        width: double.infinity,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return const Text('Не удалось загрузить изображение');
                        },
                      ),
                    ),

                  const SizedBox(height: 16),
                  TextField(
                    controller: _answerController,
                    decoration: const InputDecoration(
                      labelText: 'Введите ответ',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _submitAnswer,
                    child: const Text('Ответить'),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'Цепочка результатов:',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: _results.isEmpty
                        ? const Center(child: Text('Пока нет ответов'))
                        : ListView.builder(
                            itemCount: _results.length,
                            itemBuilder: (context, index) {
                              final item = _results[index];
                              return Card(
                                child: ListTile(
                                  title: Text('Task ID: ${item.taskId}'),
                                  subtitle: Text('Ответ: ${item.userAnswer}'),
                                  trailing: Text(
                                    item.isCorrect ? 'Верно' : 'Неверно',
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
          ),
        ),
      ),
    );
  }
}