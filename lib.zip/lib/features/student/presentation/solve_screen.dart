import 'package:flutter/material.dart';
import '../../core/app_routes.dart';
import '../data/hash_service.dart';

class SolveScreen extends StatefulWidget {
  const SolveScreen({super.key});

  @override
  State<SolveScreen> createState() => _SolveScreenState();
}

class _SolveScreenState extends State<SolveScreen> {
  final TextEditingController _controller = TextEditingController();

  String? _errorText;

  bool get _isValid {
    final value = _controller.text.trim();

    if (value.length < 3) {
      return false;
    }

    final regExp = RegExp(r'^[A-Za-z0-9\-]+$');
    return regExp.hasMatch(value);
  }

  void _validateInput() {
    final value = _controller.text.trim();

    if (value.isEmpty) {
      setState(() {
        _errorText = 'Введите код задания';
      });
      return;
    }

    if (value.length < 3) {
      setState(() {
        _errorText = 'Код слишком короткий';
      });
      return;
    }

    final regExp = RegExp(r'^[A-Za-z0-9\-]+$');
    if (!regExp.hasMatch(value)) {
      setState(() {
        _errorText = 'Допустимы только буквы, цифры и дефис';
      });
      return;
    }

    setState(() {
      _errorText = null;
    });
  }

  void _startTest() {
    _validateInput();

    if (_errorText != null) {
      return;
    }

    final decoded = HashService.decodeHashUsl(_controller.text.trim());

    if (decoded == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Не удалось декодировать hashUsl'),
        ),
      );
      return;
    }

    Navigator.pushNamed(
      context,
      AppRoutes.studentTask,
      arguments: {
        'startTaskId': decoded.startTaskId,
        'seed': decoded.seed,
      },
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ввод кода'),
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 500),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                const Text(
                  'Введите hashUsl, чтобы начать тест',
                  style: TextStyle(fontSize: 18),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _controller,
                  decoration: InputDecoration(
                    labelText: 'Код задания',
                    hintText: 'Например: 1-abc123',
                    border: const OutlineInputBorder(),
                    errorText: _errorText,
                  ),
                  onChanged: (_) {
                    setState(() {
                      _validateInput();
                    });
                  },
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: _isValid ? _startTest : null,
                  child: const Text('Начать тест'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}