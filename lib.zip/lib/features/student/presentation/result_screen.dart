import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_routes.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

    final hashRes = args?['hashRes']?.toString() ?? 'Нет результата';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Результат'),
      ),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 600),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
          children: [
            const Text(
              'Итоговый hashRes',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            SelectableText(
              hashRes,
              style: const TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: hashRes));

                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('hashRes скопирован'),
                    ),
                  );
                }
              },
              child: const Text('Копировать'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  AppRoutes.studentMain,
                  (route) => false,
                );
              },
              child: const Text('На главный экран'),
            ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}