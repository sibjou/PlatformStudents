class AppRoutes {
  static const roleSelection = '/role';
  static const studentMain = '/student';
  static const studentSolve = '/student/solve';
  static const studentTask = '/student/task';
  static const studentResult = '/student/result';
}