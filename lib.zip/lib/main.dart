import 'package:flutter/material.dart';
import 'features/core/app_routes.dart';
import 'features/student/presentation/student_main_screen.dart';
import 'features/student/presentation/solve_screen.dart';
import 'features/student/presentation/task_screen.dart';
import 'features/student/presentation/result_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: AppRoutes.studentMain,
      routes: {
        AppRoutes.studentMain: (_) => const StudentMainScreen(),
        AppRoutes.studentSolve: (_) => const SolveScreen(),
        AppRoutes.studentTask: (_) => const TaskScreen(),
        AppRoutes.studentResult: (_) => const ResultScreen(),
      },
    );
  }
}